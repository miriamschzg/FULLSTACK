

// alert("Hola Mundo");
let producto = "Nombre del producto";
let disponible;

disponible =true;
disponible = "No hay producto";



let camiseta ="red",
    pantalon ="yellow",
    zapatos;

console.log("CAMISETA:",camiseta);

zapatos="negros";
console.log("color del pantalon:",pantalon);
console.log("color del zapato:", zapatos)

// var contador = 0;
// if (contador<2){
//     var total =2;
// }
// console.log (total)

const constante ="valor constante";
console.log("constante:", constante);